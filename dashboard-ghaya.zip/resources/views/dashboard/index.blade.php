@extends('dashboard.layout')

@section('content')
    <h1>مرحباً بك في لوحة التحكم</h1>
@endsection
