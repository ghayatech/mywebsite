<?php $__env->startSection('content'); ?>
    <h1 class="text-2xl font-bold mb-4">تعديل قسم من نحن</h1>
    <?php if(session('success')): ?>
        <div class="bg-green-100 text-green-700 px-4 py-2 mb-4 rounded">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('dashboard.about.update')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="grid grid-cols-2 gap-4 mb-6">
            <div>
                <label class="block mb-2">صورة القسم</label>
                <input type="file" name="image" class="w-full border px-4 py-2 rounded">
                <?php if($about && $about->image): ?>
                    <img src="<?php echo e(asset($about->image)); ?>" class="w-32 mt-2">
                <?php endif; ?>
            </div>
        </div>

        <div class="flex space-x-4 mb-4">
            <?php $__currentLoopData = config('app.available_locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="w-1/2">
                    <h2 class="text-xl font-semibold mb-2"><?php echo e(strtoupper($locale)); ?></h2>

                    <label>العنوان</label>
                    <input type="text" name="about[<?php echo e($locale); ?>][title]"
                        value="<?php echo e($about?->translations->firstWhere('locale', $locale)?->title); ?>"
                        class="w-full mb-2 border px-4 py-2 rounded">

                    <label>الفقرة الأولى</label>
                    <textarea name="about[<?php echo e($locale); ?>][paragraph1]" class="w-full mb-2 border px-4 py-2 rounded" rows="3"><?php echo e($about?->translations->firstWhere('locale', $locale)?->paragraph1); ?></textarea>

                    <label>الفقرة الثانية</label>
                    <textarea name="about[<?php echo e($locale); ?>][paragraph2]" class="w-full mb-2 border px-4 py-2 rounded" rows="3"><?php echo e($about?->translations->firstWhere('locale', $locale)?->paragraph2); ?></textarea>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <button type="submit" class="px-6 py-2 bg-blue-600 text-white rounded">حفظ</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\dashboard-ghaya\resources\views/dashboard/about/edit.blade.php ENDPATH**/ ?>