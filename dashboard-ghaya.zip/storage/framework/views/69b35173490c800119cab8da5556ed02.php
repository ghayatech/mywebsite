<?php $__env->startSection('content'); ?>
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-2xl font-bold">إدارة قائمة الموقع</h1>
        <a href="<?php echo e(route('dashboard.menus.create')); ?>" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
            إضافة رابط جديد
        </a>
    </div>

    <?php if(session('success')): ?>
        <div class="bg-green-100 text-green-700 p-4 mb-4 rounded">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="overflow-x-auto">
        <table class="w-full table-auto border-collapse">
            <thead class="bg-gray-100">
                <tr>
                    <th class="px-4 py-2 border">النص (<?php echo e(app()->getLocale()); ?>)</th>
                    <th class="px-4 py-2 border">الرابط URL</th>
                    <th class="px-4 py-2 border">إجراءات</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="text-center">
                        <td class="px-4 py-2 border"><?php echo e($menu->translation()?->name); ?></td>
                        <td class="px-4 py-2 border"><?php echo e($menu->url); ?></td>
                        <td class="px-4 py-2 border flex justify-center gap-2">
                            <a href="<?php echo e(route('dashboard.menus.edit', $menu)); ?>"
                                class="bg-yellow-400 text-white px-3 py-1 rounded hover:bg-yellow-500">تعديل</a>
                            <form action="<?php echo e(route('dashboard.menus.destroy', $menu)); ?>" method="POST"
                                onsubmit="return confirm('هل أنت متأكد من الحذف؟');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit"
                                    class="bg-red-600 text-white px-3 py-1 rounded hover:bg-red-700">حذف</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\dashboard-ghaya\resources\views/dashboard/menus/index.blade.php ENDPATH**/ ?>