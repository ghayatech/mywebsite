<?php $__env->startSection('content'); ?>
    <div class="mb-6">
        <h1 class="text-2xl font-bold">تعديل الخدمة</h1>
    </div>

    <form action="<?php echo e(route('dashboard.services.update', $service)); ?>" method="POST" enctype="multipart/form-data"
        class="space-y-6">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div>
            <label>الأيقونة</label>
            <input type="text" name="icon" value="<?php echo e(old('icon', $service->icon)); ?>"
                class="w-full border rounded px-4 py-2 mt-1">
        </div>

        <div>
            <label>صورة الخدمة</label>
            <input type="file" name="image" class="w-full border rounded px-4 py-2 mt-1">
            <?php if($service->image): ?>
                <img src="<?php echo e(asset($service->image)); ?>" alt="Current Image" class="h-24 mt-2">
            <?php endif; ?>
        </div>

        <?php $__currentLoopData = ['ar' => 'العربية', 'en' => 'الإنجليزية']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale => $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $translation = $service->translations->where('locale', $locale)->first();
            ?>
            <div class="border p-4 rounded">
                <h2 class="font-semibold mb-4">اللغة: <?php echo e($language); ?></h2>

                <div class="mb-4">
                    <label>العنوان</label>
                    <input type="text" name="translations[<?php echo e($locale); ?>][title]"
                        value="<?php echo e(old('translations.' . $locale . '.title', $translation?->title)); ?>"
                        class="w-full border rounded px-4 py-2 mt-1">
                </div>

                <div>
                    <label>الوصف</label>
                    <textarea name="translations[<?php echo e($locale); ?>][description]" rows="4"
                        class="w-full border rounded px-4 py-2 mt-1"><?php echo e(old('translations.' . $locale . '.description', $translation?->description)); ?></textarea>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700">تحديث</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\dashboard-ghaya\resources\views/dashboard/services/edit.blade.php ENDPATH**/ ?>