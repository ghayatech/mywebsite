<?php $__env->startSection('content'); ?>
    <div class="mb-6">
        <h1 class="text-2xl font-bold">إضافة رابط جديد</h1>
    </div>

    <form action="<?php echo e(route('dashboard.menus.store')); ?>" method="POST" class="space-y-6">
        <?php echo csrf_field(); ?>

        <div>
            <label>الرابط URL</label>
            <input type="text" name="url" class="w-full border rounded px-4 py-2 mt-1">
        </div>

        <?php $__currentLoopData = ['ar' => 'العربية', 'en' => 'الإنجليزية']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale => $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="border p-4 rounded">
                <h2 class="font-semibold mb-4"><?php echo e($language); ?></h2>

                <div>
                    <label>نص الرابط</label>
                    <input type="text" name="translations[<?php echo e($locale); ?>][name]"
                        class="w-full border rounded px-4 py-2 mt-1">
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700">حفظ</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\dashboard-ghaya\resources\views/dashboard/menus/create.blade.php ENDPATH**/ ?>