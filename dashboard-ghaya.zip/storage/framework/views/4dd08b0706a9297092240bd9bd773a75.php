<?php $__env->startSection('content'); ?>
    <div class="container mx-auto p-6 bg-white rounded shadow">
        <h1 class="text-2xl font-bold mb-4">تعديل قسم فريق العمل</h1>

        <form action="<?php echo e(route('dashboard.team.update')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="grid grid-cols-2 gap-4 mb-6">
                <?php $__currentLoopData = config('app.available_locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="border p-4 rounded">
                        <h2 class="text-xl mb-2"><?php echo e(strtoupper($locale)); ?></h2>

                        <label>العنوان</label>
                        <input type="text" name="section[<?php echo e($locale); ?>][title]"
                            value="<?php echo e($teamSection?->translations->firstWhere('locale', $locale)?->title); ?>"
                            class="w-full mb-2 border px-4 py-2 rounded">

                        <label>الوصف</label>
                        <textarea name="section[<?php echo e($locale); ?>][description]" class="w-full mb-2 border px-4 py-2 rounded" rows="3"><?php echo e($teamSection?->translations->firstWhere('locale', $locale)?->description); ?></textarea>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <button type="submit" class="px-6 py-2 bg-blue-600 text-white rounded">حفظ القسم</button>
        </form>

        <hr class="my-6">

        <h2 class="text-2xl font-bold mb-4">أعضاء الفريق</h2>

        <form action="<?php echo e(route('dashboard.team.member.store')); ?>" method="POST" enctype="multipart/form-data"
            class="mb-8">
            <?php echo csrf_field(); ?>
            <div class="grid grid-cols-2 gap-4 mb-4">
                <div>
                    <label>صورة العضو</label>
                    <input type="file" name="image" class="w-full border px-4 py-2 rounded">
                </div>
                <div>

                </div>
                <?php $__currentLoopData = config('app.available_locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="border p-4 rounded">
                        <h2 class="text-xl mb-2"><?php echo e(strtoupper($locale)); ?></h2>

                        <input type="text" name="member[<?php echo e($locale); ?>][name]" placeholder="اسم العضو"
                            class="w-full mb-2 border px-4 py-2 rounded">
                        <input type="text" name="member[<?php echo e($locale); ?>][position]" placeholder="المسمى الوظيفي"
                            class="w-full mb-2 border px-4 py-2 rounded">
                        <textarea name="member[<?php echo e($locale); ?>][task_description]" placeholder="وصف المهام"
                            class="w-full mb-2 border px-4 py-2 rounded"></textarea>
                        <input type="text" name="member[<?php echo e($locale); ?>][experience]" placeholder="الخبرة"
                            class="w-full mb-2 border px-4 py-2 rounded">
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <button type="submit" class="px-6 py-2 bg-green-600 text-white rounded">إضافة عضو جديد</button>
        </form>

        <div class="grid grid-cols-3 gap-4">
            <?php $__currentLoopData = $teamMembers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="border p-4 rounded shadow">
                    <form action="<?php echo e(route('dashboard.team.member.update', $member->id)); ?>" method="POST"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <img src="<?php echo e(asset($member->image)); ?>" class="w-full h-48 object-cover mb-2">

                        <div class="mb-4">
                            <label>تغيير الصورة (اختياري)</label>
                            <input type="file" name="image" class="w-full mb-2 border px-4 py-2 rounded">
                        </div>

                        <?php $__currentLoopData = config('app.available_locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="border p-2 rounded mb-2">
                                <h4 class="text-md font-bold mb-2"><?php echo e(strtoupper($locale)); ?></h4>

                                <input type="text" name="member[<?php echo e($locale); ?>][name]"
                                    value="<?php echo e($member->translations->firstWhere('locale', $locale)?->name); ?>"
                                    placeholder="اسم العضو" class="w-full mb-2 border px-4 py-2 rounded">
                                <input type="text" name="member[<?php echo e($locale); ?>][position]"
                                    value="<?php echo e($member->translations->firstWhere('locale', $locale)?->position); ?>"
                                    placeholder="المسمى الوظيفي" class="w-full mb-2 border px-4 py-2 rounded">
                                <textarea name="member[<?php echo e($locale); ?>][task_description]" class="w-full mb-2 border px-4 py-2 rounded"
                                    placeholder="وصف المهام"><?php echo e($member->translations->firstWhere('locale', $locale)?->task_description); ?></textarea>
                                <input type="text" name="member[<?php echo e($locale); ?>][experience]"
                                    value="<?php echo e($member->translations->firstWhere('locale', $locale)?->experience); ?>"
                                    placeholder="الخبرة" class="w-full mb-2 border px-4 py-2 rounded">
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded text-sm">تحديث العضو</button>
                    </form>

                    <form action="<?php echo e(route('dashboard.team.member.destroy', $member->id)); ?>" method="POST" class="mt-2">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="px-4 py-1 bg-red-600 text-white rounded text-sm">حذف</button>
                    </form>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\dashboard-ghaya\resources\views/dashboard/team/index.blade.php ENDPATH**/ ?>