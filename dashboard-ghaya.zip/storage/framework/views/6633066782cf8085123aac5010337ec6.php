<?php $__env->startSection('content'); ?>
    
    <h1 class="text-2xl font-bold mb-6">إحصائيات الشركة</h1>

    <?php if(session('success')): ?>
        <div class="bg-green-100 text-green-700 px-4 py-2 mb-4 rounded">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('dashboard.statistics.update')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="flex space-x-4 rtl:space-x-reverse mb-6">
            <button type="button" onclick="showTab('ar')"
                class="tab-button bg-blue-500 text-white px-4 py-2 rounded">العربية</button>
            <button type="button" onclick="showTab('en')" class="tab-button bg-gray-200 px-4 py-2 rounded">English</button>
        </div>

        
        <div class="tab-content" id="tab-ar">
            <?php if (isset($component)) { $__componentOriginald68985950125b305a57a323ed8924952 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald68985950125b305a57a323ed8924952 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.statistic-form-fields','data' => ['statistic' => $statisticAr,'locale' => 'ar']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('statistic-form-fields'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['statistic' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($statisticAr),'locale' => 'ar']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald68985950125b305a57a323ed8924952)): ?>
<?php $attributes = $__attributesOriginald68985950125b305a57a323ed8924952; ?>
<?php unset($__attributesOriginald68985950125b305a57a323ed8924952); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald68985950125b305a57a323ed8924952)): ?>
<?php $component = $__componentOriginald68985950125b305a57a323ed8924952; ?>
<?php unset($__componentOriginald68985950125b305a57a323ed8924952); ?>
<?php endif; ?>
        </div>

        
        <div class="tab-content hidden" id="tab-en">
            <?php if (isset($component)) { $__componentOriginald68985950125b305a57a323ed8924952 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald68985950125b305a57a323ed8924952 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.statistic-form-fields','data' => ['statistic' => $statisticEn,'locale' => 'en']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('statistic-form-fields'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['statistic' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($statisticEn),'locale' => 'en']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald68985950125b305a57a323ed8924952)): ?>
<?php $attributes = $__attributesOriginald68985950125b305a57a323ed8924952; ?>
<?php unset($__attributesOriginald68985950125b305a57a323ed8924952); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald68985950125b305a57a323ed8924952)): ?>
<?php $component = $__componentOriginald68985950125b305a57a323ed8924952; ?>
<?php unset($__componentOriginald68985950125b305a57a323ed8924952); ?>
<?php endif; ?>
        </div>

        <div class="mt-6">
            <button type="submit" class="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded">
                💾 حفظ التغييرات
            </button>
        </div>

    </form>

    <script>
        function showTab(lang) {
            document.querySelectorAll('.tab-content').forEach(div => div.classList.add('hidden'));
            document.getElementById('tab-' + lang).classList.remove('hidden');

            document.querySelectorAll('.tab-button').forEach(btn => {
                btn.classList.remove('bg-blue-500', 'text-white');
                btn.classList.add('bg-gray-200');
            });

            const clickedBtn = document.querySelector('[onclick="showTab(\'' + lang + '\')"]');
            clickedBtn.classList.remove('bg-gray-200');
            clickedBtn.classList.add('bg-blue-500', 'text-white');
        }

        // افتراضيًا أظهر التبويب العربي
        window.onload = function() {
            showTab('ar');
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\dashboard-ghaya\resources\views/dashboard/statistic/edit.blade.php ENDPATH**/ ?>