<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['statistic', 'locale']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['statistic', 'locale']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="grid grid-cols-1 md:grid-cols-2 gap-6">

    <input type="hidden" name="statistic[<?php echo e($locale); ?>][locale]" value="<?php echo e($locale); ?>">

    <div>
        <label>النص الأساسي (Main Text)</label>
        <input type="text" name="statistic[<?php echo e($locale); ?>][main_text]"
            value="<?php echo e(old("statistic.$locale.main_text", $statistic->main_text)); ?>"
            class="w-full border px-4 py-2 rounded">
    </div>

    <div>
        <label>العنوان</label>
        <input type="text" name="statistic[<?php echo e($locale); ?>][title]"
            value="<?php echo e(old("statistic.$locale.title", $statistic->title)); ?>" class="w-full border px-4 py-2 rounded">
    </div>

    <div>
        <label>العداد</label>
        <input type="text" name="statistic[<?php echo e($locale); ?>][number]"
            value="<?php echo e(old("statistic.$locale.number", $statistic->number)); ?>" class="w-full border px-4 py-2 rounded">
    </div>

</div>
<?php /**PATH C:\laragon\www\dashboard-ghaya\resources\views/components/statistic-form-fields.blade.php ENDPATH**/ ?>