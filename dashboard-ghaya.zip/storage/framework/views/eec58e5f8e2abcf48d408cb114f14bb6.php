<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('dashboard.team.member.update', $member->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div>
            <label>الصورة الحالية:</label>
            <?php if($member->image): ?>
                <img src="<?php echo e(asset($member->image)); ?>" width="100" alt="صورة العضو">
            <?php endif; ?>
            <input type="file" name="image">
        </div>

        <?php $__currentLoopData = config('app.available_locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div>
                <h4>اللغة: <?php echo e(strtoupper($locale)); ?></h4>

                <input type="text" name="member[<?php echo e($locale); ?>][name]" placeholder="اسم العضو"
                    class="w-full mb-2 border px-4 py-2 rounded" value="member[<?php echo e($locale); ?>][name]">
                <input type="text" name="member[<?php echo e($locale); ?>][position]" placeholder="المسمى الوظيفي"
                    class="w-full mb-2 border px-4 py-2 rounded">
                <textarea name="member[<?php echo e($locale); ?>][task_description]" placeholder="وصف المهام"
                    class="w-full mb-2 border px-4 py-2 rounded"></textarea>
                <input type="text" name="member[<?php echo e($locale); ?>][experience]" placeholder="الخبرة"
                    class="w-full mb-2 border px-4 py-2 rounded">
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <button type="submit" class="btn btn-success">حفظ التعديلات</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\dashboard-ghaya\resources\views/dashboard/team/edit.blade.php ENDPATH**/ ?>