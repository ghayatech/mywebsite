<?php $__env->startSection('content'); ?>
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-2xl font-bold">الخدمات</h1>
        <a href="<?php echo e(route('dashboard.services.create')); ?>"
            class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">إضافة خدمة جديدة</a>
    </div>

    <?php if(session('success')): ?>
        <div class="bg-green-100 text-green-700 p-4 mb-4 rounded">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="border rounded p-4 flex flex-col items-center text-center">
                <?php if($service->image): ?>
                    <img src="<?php echo e(asset($service->image)); ?>" alt="Service Image" class="h-24 mb-4 object-cover">
                <?php endif; ?>
                <div class="text-4xl mb-2"><?php echo e($service->icon); ?></div>
                <h2 class="font-bold text-lg mb-2"><?php echo e($service->translation()?->title ?? 'لا يوجد عنوان'); ?></h2>
                <p class="text-gray-600 mb-4"><?php echo e(Str::limit($service->translation()?->description, 100)); ?></p>
                <div class="flex gap-2">
                    <a href="<?php echo e(route('dashboard.services.edit', $service)); ?>"
                        class="bg-yellow-400 text-white px-3 py-1 rounded hover:bg-yellow-500">تعديل</a>
                    <form action="<?php echo e(route('dashboard.services.destroy', $service)); ?>" method="POST"
                        onsubmit="return confirm('هل أنت متأكد من الحذف؟');">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="bg-red-600 text-white px-3 py-1 rounded hover:bg-red-700">حذف</button>
                    </form>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\dashboard-ghaya\resources\views/dashboard/services/index.blade.php ENDPATH**/ ?>